# 1.Create a function called is_even that takes an integer num as a parameter and returns True if it's even and False if it's odd. Use modulas

def is_even(num):
    return num % 2 == 0
print(is_even(4))
print(is_even(7))
print(is_even(3))
print(is_even(2))
print("==========================================")



# 2.	Define a function calculate_cylinder that takes the radius and height of a cylinder as a parameter and returns its volume. Use the formula: volume = π * r^2*h.

def calculate_cylinder(radius , height , pi ):
    volume = (pi * radius**2) * height
    print("The volume of the cylinder is :" , volume)
calculate_cylinder(7 , 4 , 3.142)


# print("=========================================================")

# def calculate_cylinder(radius , height , pi ):
#     return (pi * radius**2) * height
# def main():
#     radius = int(input("Enter the radius: "))
#     height = int(input("Enter the height: "))
#     area_cylinder = calculate_cylinder(radius , height , pi= 3.142)
#     print("The volume of a cylinder is : " , area_cylinder)
# main()


print("==============================================")



# 3.	Create a function that calculates simple interest, use parameters. P*t*r/100

def simple_interest (principle , rate , time):
    interest = principle * rate * time / 100
    print("The simple interest is :" , interest)
simple_interest(4,3,2)

# print("====================================================")

# def simple_interest (principle , rate , time):
#      return principle * rate * time / 100


# def main():
#     principle = int(input("Enter the principle: "))
#     rate = int(input("Enter the rate: "))
#     time = int(input("Enter the time: "))
#     simp_i = simple_interest(principle , rate , time)
#     print("The simple interest is : " , simp_i)
    
# main()
